import React from "react";

export default function HomePage() {
  return (
    <div className="bg-white text-gray-800">
      {/* Header */}
      <header className="flex justify-between items-center p-4 shadow-md bg-white">
        <div className="text-2xl font-bold text-green-700">
          <span className="text-yellow-600">Liquid</span> Gold
        </div>
        <nav className="space-x-4 hidden md:block">
          <a href="#" className="text-gray-700 hover:text-green-700">Home</a>
          <a href="#" className="text-gray-700 hover:text-green-700">Shop</a>
          <a href="#" className="text-gray-700 hover:text-green-700">About</a>
          <a href="#" className="text-gray-700 hover:text-green-700">Contact</a>
        </nav>
        <div className="hidden md:block">
          <input
            type="text"
            placeholder="Search..."
            className="border rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-green-600"
          />
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-green-50 py-16 text-center px-4">
        <h1 className="text-4xl md:text-5xl font-extrabold text-green-800 mb-4">
          Discover the Power of Organic Living
        </h1>
        <p className="text-lg text-gray-700 mb-6">
          Premium honey, ghee, and oils sourced directly from nature.
        </p>
        <button className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-full text-lg font-semibold transition duration-300">
          Shop Now
        </button>
      </section>
    </div>
  );
}